const token =
    "eyJhbGciOiJIUzI1NiJ9.eyJhdWQiOiJjOTk2OTA2N2EzMjE4Y2U0M2M0OTE1ODYwZmI1YTY4MSIsIm5iZiI6MTczOTg4NDM3My4yMTIsInN1YiI6IjY3YjQ4NzU1OTFkN2U2NmM2NTZkZDFmZiIsInNjb3BlcyI6WyJhcGlfcmVhZCJdLCJ2ZXJzaW9uIjoxfQ.6Br1nDrZmToRWUlTfdv90vyrGd0XTKU4tOu8X23lkBY";

const fetchTrending = (sortBy) => {
    const url = `https://api.themoviedb.org/3/trending/all/${sortBy}?language=fr-FR`;
    const options = {
        method: "GET",
        headers: {
            accept: "application/json",
            Authorization: `Bearer ${token}`,
        },
    };

    fetch(url, options)
        .then((res) => res.json())
        .then((json) => displayAllTrending(json))
        .catch((err) => console.error(err));
};

function displayAllTrending(json) {
    console.log(json);
    const options = {
        year: "numeric",
        month: "long",
        day: "numeric",
    };
    const gridTendance = document.querySelector("#tendances");
    for (let loopThroughFilm = 0; loopThroughFilm < 4; loopThroughFilm++) {
        const film = json.results[loopThroughFilm];
        gridTendance.children[loopThroughFilm].innerHTML = `
        <img src="https://www.themoviedb.org/t/p/w500${
            film.poster_path
        }" alt="" srcset='img/popcorn.svg' onload="this.srcset=''"/>
        <div class="score"><p>${Math.round(film.vote_average * 10)}%</p></div>
        <h5>${film.media_type === "tv" ? film.name : film.title}</h5>
        <p>${new Date(
            film.media_type === "tv" ? film.first_air_date : film.release_date
        ).toLocaleDateString("fr-FR", options)}</p>
        `;
    }
}

export { fetchTrending };
