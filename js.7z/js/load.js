import { fetchTrending } from "./allTrending.js";
import { fetchTV } from "./TV.js";

fetchTrending("day");
fetchTV("top_rated");
